#' @title Function to find right amount of tickets to sell
#'
#' @param N Number of seats on the flight
#' @param gamma Probabilty that the flight is overbooked
#' @param p Probabilty that the passenger shows up
#'
#' @return A list of discrete and constinuos results and the graphs with the input variables
#' @export
#'
#' @examples
#'\dontrun{ntickets(400, 0.02, 0.95)}
ntickets = function(N, gamma, p) {

  n = seq(N, floor(N + N / 10), by = 1)

  tempD = 1 - gamma - pbinom(q = N, size = n, prob = p)

  index = which.min(abs(tempD))

  mean = N*p
  std = sqrt(mean*(1 - p))
  tempC = 1 - gamma - pnorm(n, mean = mean, sd = std)

  indexC = which.min(abs(tempC))

  plot(n, tempD, type = "b", col = "blue", lwd = 1.5, main = paste("Objective vs n to Find Optimal Tickets Sold - Discrete"), xlab = "n", ylab = "Objective")

  abline(h = 0, col = "red")
  abline(v = n[index], col = "red", lwd = 1.5)

  plot(n, tempC, type = "b", col = "green", lwd = 1.5, main = paste("Objective vs n to Find Optimal Tickets Sold - Continuous"), xlab = "n", ylab = "Objective")

  abline(h = 0, col = "blue")
  abline(v = n[indexC], col = "blue", lwd = 1.5)
  list(nd = n[index], nc = n[indexC], N = N, p = p, gamma = gamma)

}
