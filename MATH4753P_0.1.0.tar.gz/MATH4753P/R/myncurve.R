#' CurvewArea
#'
#' @param a variable
#' @param mu mean
#' @param sigma standard deviation
#'
#' @return A curve with a shaded area
#' @export
#'
#' @examples \dontrun{myncurve(mu=10,sigma=5, a=6)}
myncurve = function(mu, sigma, a){
  curve(dnorm(x,mean=mu,sd=sigma), xlim = c(mu-3*sigma, mu + 3*sigma))
  list(mu = mu, sigma = sigma)

  xcurve=seq(0,a,length=1000)
  ycurve=dnorm(xcurve,mean=mu,sd=sigma)

  polygon(c(0,xcurve,a),c(0,ycurve,0),col="Red")
  area = pnorm(a, mean=mu,sd=sigma) - pnorm(2, mean=mu,sd=sigma)
  area = round(area,4)

  text(x = 2.15, y = 0.025, paste("Area = ", area, sep = ""))
}
