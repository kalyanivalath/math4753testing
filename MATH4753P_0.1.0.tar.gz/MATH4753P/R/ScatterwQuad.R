#' @title Scatter plot with Quadratic curve
#'
#' @param x X variable
#'
#' @return A sophisticated scatterplot with a curve
#' @export
#'
#' @examples
#' \dontrun{curve(myplot, lwd=2, col="steelblue",add=TRUE)}
myplot = function(x) {
  quad.lm$coef[1] + quad.lm$coef[2]*x  + quad.lm$coef[3]*x^2
}
